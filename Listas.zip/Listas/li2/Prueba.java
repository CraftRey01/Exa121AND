public class Main {
    public static void main(String[] args) {
        LSNormal lista = new LSNormal();

        // Agregar elementos a la lista
        lista.adiFinal(1);
        lista.adiFinal(2);
        lista.adiFinal(3);
        lista.adiFinal(4);
        lista.adiFinal(5);

        // Mostrar la lista original
        System.out.println("Lista Original:");
        lista.mostrar();

        // Añadir un nuevo número después del i-ésimo nodo
        int posicionAInsertar = 3;
        int nuevoNumero = 10;
        lista.agregar(posicionAInsertar, nuevoNumero);

        // Mostrar la lista después de la inserción
        System.out.println("\nLista Después de la Inserción:");
        lista.mostrar();

        // Eliminar el número X de toda la lista
        int numeroAEliminar = 3;
        lista.eliminar(numeroAEliminar);

        // Mostrar la lista después de la eliminación
        System.out.println("\nLista Después de la Eliminación:");
        lista.mostrar();
    }
}

class NodoS {
    private int dato;
    private NodoS sig;

    public NodoS() {
        dato = 0;
        sig = null;
    }

    public int getDato() {
        return dato;
    }

    public void setDato(int x) {
        dato = x;
    }

    public NodoS getSig() {
        return sig;
    }

    public void setSig(NodoS s) {
        sig = s;
    }
}

class LSNormal {
    private NodoS p; // Cabecera de la lista

    public LSNormal() {
        p = null;
    }

    // Getters y setters de LSNormal
    public NodoS getCabecera() {
        return p;
    }

    public void setCabecera(NodoS q) {
        p = q;
    }

    // Método para agregar al final de la lista
    public void adiFinal(int da) {
        NodoS x, u;
        x = new NodoS();
        x.setDato(da);
        if (esVacia())
            p = x;
        else {
            u = p;
            while (u.getSig() != null)
                u = u.getSig();
            u.setSig(x);
        }
    }

    // Método para mostrar la lista
    public void mostrar() {
        NodoS y;
        if (esVacia())
            System.out.println("Lista vacía");
        else {
            y = p;
            while (y != null) {
                System.out.print("\t" + y.getDato());
                y = y.getSig();
            }
            System.out.println();
        }
    }

    // Método que verifica si la lista es vacía
    public boolean esVacia() {
        return (p == null);
    }

    // Método para añadir un nuevo número después del i-ésimo nodo
    public void agregar(int i, int nuevoNumero) {
        NodoS r = p;
        int c = 0;
        while (r != null) {
            c = c + 1;
            if (c == i) {
                NodoS nuevoNodo = new NodoS();
                nuevoNodo.setDato(nuevoNumero);
                nuevoNodo.setSig(r.getSig());
                r.setSig(nuevoNodo);
            }
            r = r.getSig();
        }
    }

    // Método para eliminar el número X de toda la lista
    public void eliminar(int x) {
        NodoS r = p;
        while (r != null) {
            if (r.getDato() == x) {
                if (r == p) {
                    p = r.getSig();
                    r.setSig(null);
                    r = p;
                } else {
                    NodoS w = p;
                    while (w.getSig() != r)
                        w = w.getSig();
                    w.setSig(r.getSig());
                    r.setSig(null);
                    r = w.getSig();
                }
            } else
                r = r.getSig();
        }
    }
}
