package Listas;

public class NodoS {
    private int dato;
    private NodoS sig;

    public NodoS() {
        dato = 0;
        sig = null;
    }

    public int getDato() {
        return dato;
    }

    public void setDato(int x) {
        dato = x;
    }

    public NodoS getSig() {
        return sig;
    }

    public void setSig(NodoS s) {
        sig = s;
    }
}
