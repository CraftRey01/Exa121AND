package Listas;

public class Main {
    public static void main(String[] args) {
        LSNormal lista = new LSNormal();

        // Agregar elementos a la lista
        lista.adiFinal(1);
        lista.adiFinal(2);
        lista.adiFinal(3);
        lista.adiFinal(4);
        lista.adiFinal(5);

        // Mostrar la lista original
        System.out.println("Lista Original:");
        lista.mostrar();

        // Añadir un nuevo número después del i-ésimo nodo
        int posicionAInsertar = 3;
        int nuevoNumero = 10;
        lista.agregar(posicionAInsertar, nuevoNumero);

        // Mostrar la lista después de la inserción
        System.out.println("\nLista Después de la Inserción:");
        lista.mostrar();

        // Eliminar el número X de toda la lista
        int numeroAEliminar = 3;
        lista.eliminar(numeroAEliminar);

        // Mostrar la lista después de la eliminación
        System.out.println("\nLista Después de la Eliminación:");
        lista.mostrar();
    }
}

//
//import java.util.Scanner;

//public class Main {
//    public static void main(String[] args) {
//        Scanner scanner = new Scanner(System.in);
//        LSNormal lista = new LSNormal();

//        // Ingresar números manualmente
//        System.out.println("Ingrese números separados por comas (0 para terminar): ");
//        String input = scanner.nextLine();
//        String[] numeros = input.split(",");

//        // Agregar números a la lista
//        for (String num : numeros) {
//            if (!num.trim().equals("0")) {
//                int numero = Integer.parseInt(num.trim());
//                lista.adiFin(numero);
//            } else {
//                break;
//            }
//        }

//        // Mostrar la lista original
//        System.out.println("Lista Original:");
//        lista.mostrar();

//        // Realizar la operación de organizar
//        organizar(lista);

//        // Mostrar la lista después de organizar
//        System.out.println("Lista Organizada:");
//        lista.mostrar();

//        scanner.close();
//    }

//    static void organizar(LSNormal lista) {
//        // Implementa la lógica de organizar aquí
//        // Utiliza la estructura de lista y nodos según sea necesario
//        // Puedes adaptar la lógica que proporcionaste anteriormente
//    }
//}
