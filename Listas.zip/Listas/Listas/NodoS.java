public class NodoS {
    private int dato;
    private NodoS sig;

    public NodoS() {
        dato = 0;
        sig = null;
    }

    // Getters y setters de NodoS
    public int getDato() {
        return dato;
    }

    public void setDato(int dato) {
        this.dato = dato;
    }

    public NodoS getSig() {
        return sig;
    }

    public void setSig(NodoS sig) {
        this.sig = sig;
    }
}
