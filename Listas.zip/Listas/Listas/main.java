import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        LSNormal lista = new LSNormal();

        // Agregar elementos a la lista
        lista.adiFinal(1);
        lista.adiFinal(2);
        lista.adiFinal(3);
        lista.adiFinal(4);
        lista.mostrar(); // Mostrar la lista antes de realizar operaciones

        // Agregar un nuevo número después del i-ésimo nodo
        System.out.print("Ingrese la posición para agregar un nuevo número: ");
        int posicionAgregar = scanner.nextInt();
        System.out.print("Ingrese el nuevo número a agregar: ");
        int nuevoNumero = scanner.nextInt();
        lista.agregar(posicionAgregar, nuevoNumero);
        lista.mostrar(); // Mostrar la lista después de agregar

        // Eliminar el número X de toda la lista
        System.out.print("Ingrese el número a eliminar: ");
        int numeroEliminar = scanner.nextInt();
        lista.eliminar(numeroEliminar);
        lista.mostrar(); // Mostrar la lista después de eliminar
    }
}
