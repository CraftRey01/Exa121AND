package Listas;

public class LSCircular extends LSimple {
    public LSCircular() {
        super();
    }

    public boolean esVacia() {
        return (super.esVacia());
    }

    public NodoS getCabecera() {
        return p;
    }

    public void setCabecera(NodoS q) {
        p = q;
    }

    public void mostrar() {
        NodoS x;
        if (!esVacia()) {
            x = p;
            while (x.getSig() != p) {
                System.out.print("\t" + x.getDato());
                x = x.getSig();
            }
            System.out.println("\t" + x.getDato());
        } else
            System.out.println("Lista vacia...");
    }

    public void adiFin(Object da) {
        NodoS  u;
        NodoS z = new NodoS();
        z.setDato(da);
        if (esVacia()) {
            z.setSig(z);
            p = z;
        } else {
            u = p;
            while (u.getSig() != p)
                u = u.getSig();
            u.setSig(z);
            z.setSig(p);
        }
    }

    public void adiPrimero(Object da) {
        NodoS z, u;
        z = new NodoS();
        z.setDato(da);
        if (esVacia())
            z.setSig(z);
        else {
            z.setSig(p);
            u = p;
            while (u.getSig() != p)
                u = u.getSig();
            u.setSig(z);
        }
        p = z;
    }

    public Object eliFin() {
        NodoS u, au = null;
        Object da = null;
        if (!esVacia()) {
            u = p;
            while (u.getSig() != p) {
                au = u;
                u = u.getSig();
            }
            da = u.getDato();
            if (u == p)
                p = null;
            else
                au.setSig(p);
        } else
            System.out.println("Lista vacia...");
        return da;
    }

    public Object eliPrimero() {
        NodoS u, ap = null;
        Object da = null;
        if (!esVacia()) {
            da = p.getDato();
            u = p;
            while (u.getSig() != p)
                u = u.getSig();
            if (u == p)
                p = null;
            else {
                ap = p;
                p = p.getSig();
                ap.setSig(null);
                u.setSig(p);
                ap = null;
            }
        } else
            System.out.println("Lista vacia...");
        return da;
    }

    public int nElem() {
        NodoS x;
        int c = 0;
        if (!esVacia()) {
            x = p;
            c = 1;
            while (x.getSig() != p) {
                c++;
                x = x.getSig();
            }
        }
        return c;
    }

    public int nVeces(Object d) {
        int c = 1, n, i;
        Object dato;
        n = nElem();
        for (i = 1; i <= n; i++) {
            dato = eliPrimero();
            adiFin(dato);
            if (d.equals(dato))
                c++;
        }
        return c;
    }

    public boolean buscar(Object ele) {
        boolean flag = false;
        if(!this.esVacia()){
            boolean ite = true;
            for(NodoS x = p ; ite ; x=x.getSig()){//al poner ite como limite, aseguramos que ocurra almenos una iteracion,
                ite= !x.getSig().equals(p);       // esto en caso de que la lista tenga solo un nodoS
                if(x.getDato().equals(ele)){ flag = true ;}
            }
        }
        return flag;
    }
}