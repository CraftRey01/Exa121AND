package Listas;

public class Main {
    //pra listas dobles solo hay que cambiar estos 2 atributos en LDNormal y LDCircular
    protected static LSNormal listaNormal = new LSNormal();
    protected static LSCircular listaCircular =  new LSCircular();

    public static void reset(){
        listaCircular = new LSCircular();
        listaNormal = new LSNormal();
    }

    public static void p1esVacia(){
        System.out.println(" lista normal ");
        System.out.println(listaNormal.esVacia());
        System.out.println(" lista circular ");
        System.out.println(listaCircular.esVacia());
        System.out.println("  insertando un elemento  ");
        listaNormal.adiFin(3);
        listaCircular.adiFin(3);
        System.out.println(" lista normal ");
        System.out.println(listaNormal.esVacia());
        System.out.println(" lista circular ");
        System.out.println(listaCircular.esVacia());
        System.out.println("  borrando el unico elemento  ");
        listaNormal.eliFin();
        listaCircular.eliFin();
        System.out.println(" lista normal ");
        System.out.println(listaNormal.esVacia());
        System.out.println(" lista circular ");
        System.out.println(listaCircular.esVacia());
        reset();
    }
    public static void p2nElem(){
        System.out.println(" lista normal ");
        System.out.println(listaNormal.nElem());
        System.out.println(" lista circular ");
        System.out.println(listaCircular.nElem());
        System.out.println("  insertando un elemento  ");
        listaNormal.adiFin(3);
        listaCircular.adiFin(3);
        System.out.println(" lista normal ");
        System.out.println(listaNormal.nElem());
        System.out.println(" lista circular ");
        System.out.println(listaCircular.nElem());
        System.out.println("  borrando el unico elemento  ");
        listaNormal.eliFin();
        listaCircular.eliFin();
        System.out.println(" lista normal ");
        System.out.println(listaNormal.nElem());
        System.out.println(" lista circular ");
        System.out.println(listaCircular.nElem());
        reset();
    }
    public static void p3adiFin(){
        System.out.println(" lista normal");
        listaNormal.mostrar();
        System.out.println(" lista circular");
        listaCircular.mostrar();
        System.out.println("insertando dos elementos con adifin");
        listaNormal.adiFin(1);
        listaNormal.adiFin(2);
        listaCircular.adiFin(1);
        listaCircular.adiFin(2);
        System.out.println(" lista normal");
        listaNormal.mostrar();
        System.out.println(" lista circular");
        listaCircular.mostrar();
        reset();
    }
    public static void p4adiPrimero(){
        System.out.println(" lista normal");
        listaNormal.mostrar();
        System.out.println(" lista circular");
        listaCircular.mostrar();
        System.out.println("insertando dos elementos con adiPriemro");
        listaNormal.adiPrimero(1);
        listaNormal.adiPrimero(2);
        listaCircular.adiPrimero(1);
        listaCircular.adiPrimero(2);
        System.out.println(" lista normal");
        listaNormal.mostrar();
        System.out.println(" lista circular");
        listaCircular.mostrar();
        reset();
    }
    public static void p5eliFin(){
        listaNormal.adiFin(1);
        listaNormal.adiFin(2);
        listaCircular.adiFin(1);
        listaCircular.adiFin(2);
        System.out.println(" lista normal");
        listaNormal.mostrar();
        System.out.println(" lista circular");
        listaCircular.mostrar();
        System.out.println("eliminando el ultimo elemento de cada lista");
        listaNormal.eliFin();
        listaCircular.eliFin();
        System.out.println(" lista normal");
        listaNormal.mostrar();
        System.out.println(" lista circular");
        listaCircular.mostrar();
        reset();
    }
    public static void p6eliPrimero(){
        listaNormal.adiFin(1);
        listaNormal.adiFin(2);
        listaCircular.adiFin(1);
        listaCircular.adiFin(2);
        System.out.println(" lista normal");
        listaNormal.mostrar();
        System.out.println(" lista circular");
        listaCircular.mostrar();
        System.out.println("eliminando el primer elemento de cada lista");
        listaNormal.eliPrimero();
        listaCircular.eliPrimero();
        System.out.println(" lista normal");
        listaNormal.mostrar();
        System.out.println(" lista circular");
        listaCircular.mostrar();
        reset();
    }
    public static void p7mostrar(){
        listaNormal.adiFin(1);
        listaNormal.adiPrimero(2);
        listaNormal.adiFin(3);
        listaCircular.adiFin(1);
        listaCircular.adiPrimero(2);
        listaCircular.adiFin(3);
        System.out.println(" lista normal");
        listaNormal.mostrar();
        System.out.println(" lista circular");
        listaCircular.mostrar();
        reset();            //las listas ahora estan vacias
        System.out.println(" lista normal");
        listaNormal.mostrar();
        System.out.println(" lista circular");
        listaCircular.mostrar();
    }
    public static void p8buscar(){
        listaNormal.adiFin(1);
        listaNormal.adiPrimero(2);
        listaNormal.adiFin(3);
        listaCircular.adiFin(1);
        listaCircular.adiPrimero(2);
        listaCircular.adiFin(3);
        System.out.println(" lista normal");
        listaNormal.mostrar();
        System.out.println(" lista circular");
        listaCircular.mostrar();
        System.out.println(" normal buscando el numero 10000  : " + listaNormal.buscar(10000));
        System.out.println(" circular buscando el numero 10000  : " + listaCircular.buscar(10000));
        System.out.println(" normal buscando el numero 3  : " + listaNormal.buscar(3));
        System.out.println(" circular buscando el numero 3  : " + listaCircular.buscar(3));
        reset();
    }
    public static void p9adiNod(){
        System.out.println(" insertando por primera vez en normal ' saldra un error '");
        listaNormal.adiNod(0, "hola");
        listaNormal.adiNod(2, "que tal");
        System.out.println(" insertando por primera vez en circular ' saldra un error '");
        listaCircular.adiNod(0, "hola");
        listaCircular.adiNod(2, "que tal");
        listaNormal.mostrar();
        listaCircular.mostrar();
        System.out.println(" insertando por primera vez en normal ");
        listaNormal.adiNod(1, "hola Nor");
        listaNormal.mostrar();
        System.out.println(" insertando por primera vez en circular ");
        listaCircular.adiNod(1, "hola Cir");
        listaCircular.mostrar();
        System.out.println(" rellenando... ");
        for(int i=1 ; i<5 ; i++){
            listaNormal.adiNod(i, i*10);
            listaCircular.adiNod(i, i*10);
        }
        System.out.println("  mostrando normal : "); listaNormal.mostrar();
        System.out.println("  mostrando circular : "); listaCircular.mostrar();
        System.out.println(" insertando como tercer dato el 'tercer' : normal ");
        listaNormal.adiNod(3, "tercer");
        listaNormal.mostrar();
        System.out.println(" insertando como tercer dato el 'tercer' : circular ");
        listaCircular.adiNod(3, "tercer");
        listaCircular.mostrar();
        reset();
    }
    public static void p10adiRef(){
        System.out.println(" rellenando... ");
        for(int i=1 ; i<5 ; i++){
            listaNormal.adiNod(i, i*10);
            listaCircular.adiNod(i, i*10);
        }
        System.out.println(" mostrando lista normal ");
        listaNormal.mostrar();
        System.out.println(" mostrando lista circular ");
        listaCircular.mostrar();
        System.out.println(" insertamos por referencia que no existe, normal : ");
        listaNormal.adiRef(100000000, "agregame");
        System.out.println(" insertamos por referencia que no existe, circular : ");
        listaCircular.adiRef(100000000, "agregame");
        System.out.println(" insertamos con ref a 20 ( este aparece delante de la referencia ) , normal : ");
        listaNormal.adiRef(20, "agregame");
        listaNormal.mostrar();
        System.out.println(" insertamos con ref a 20 ( este aparece delante de la referencia ) , circular : ");
        listaCircular.adiRef(20, "agregame");
        listaCircular.mostrar();
        reset();
    }
    public static void p11eliNod(){
        System.out.println(" eliminamos datos ' saldra error por que esta vacio normal ' ");
        listaNormal.eliNod(0);
        listaNormal.eliNod(1);
        listaNormal.eliNod(2);
        System.out.println(" eliminamos datos ' saldra error por que esta vacio circular ' ");
        listaCircular.eliNod(0);
        listaCircular.eliNod(1);
        listaCircular.eliNod(2);
        System.out.println(" rellenando... ");
        for(int i=1 ; i<5 ; i++){
            listaNormal.adiNod(i, i*10);
            listaCircular.adiNod(i, i*10);
        }
        System.out.println(" mostrando lista normal ");
        listaNormal.mostrar();
        System.out.println(" mostrando lista circular ");
        listaCircular.mostrar();
        System.out.println("ahora eliminaremos el tercer dato normal");
        listaNormal.eliNod(3);
        listaNormal.mostrar();
        System.out.println("ahora eliminaremos el tercer dato circular");
        listaCircular.eliNod(3);
        listaCircular.mostrar();
        reset();
    }
    public static void p12eliRef(){
        System.out.println(" eliminamos datos ' saldra error por que esta vacio normal ' ");
        listaNormal.eliRef(0);
        listaNormal.eliRef("nose");
        listaNormal.eliRef(322322);
        System.out.println(" eliminamos datos ' saldra error por que esta vacio circular ' ");
        listaCircular.eliRef(0);
        listaCircular.eliRef("nose");
        listaCircular.eliRef(322322);
        System.out.println(" rellenando... ");
        for(int i=1 ; i<5 ; i++){
            listaNormal.adiNod(i, i*10);
            listaCircular.adiNod(i, i*10);
        }
        System.out.println(" mostrando lista normal ");
        listaNormal.mostrar();
        System.out.println(" mostrando lista circular ");
        listaCircular.mostrar();
        System.out.println("ahora eliminaremos el dato '20' normal");
        listaNormal.eliRef(20);
        listaNormal.mostrar();
        System.out.println("ahora eliminaremos el dato '20' circular");
        listaCircular.eliRef(20);
        listaCircular.mostrar();
        System.out.println("ahora eliminaremos el dato '40' normal");
        listaNormal.eliRef(40);
        listaNormal.mostrar();
        System.out.println("ahora eliminaremos el dato '40' circular");
        listaCircular.eliRef(40);
        listaCircular.mostrar();
        System.out.println("ahora eliminaremos el dato '10' normal");
        listaNormal.eliRef(10);
        listaNormal.mostrar();
        System.out.println("ahora eliminaremos el dato '10' circular");
        listaCircular.eliRef(10);
        listaCircular.mostrar();
        reset();
    }
    public static void p13vaciarIni(){
        System.out.println(" rellenando... ");
        for(int i=1 ; i<5 ; i++){
            listaNormal.adiNod(i, i*2);
            listaCircular.adiNod(i, (i*2)+1);
        }
        System.out.println(" mostrando lista normal ");
        listaNormal.mostrar();
        System.out.println(" mostrando lista circular ");
        listaCircular.mostrar();
        System.out.println(" vaciamos los impares en los pares pero de su inicio ");
        listaCircular.vaciarIni(listaNormal);
        listaNormal.mostrar();
        reset();
    }
    public static void p14vaciarFin(){
        System.out.println(" rellenando... ");
        for(int i=1 ; i<5 ; i++){
            listaNormal.adiNod(i, i*2);
            listaCircular.adiNod(i, (i*2)+1);
        }
        System.out.println(" mostrando lista normal ");
        listaNormal.mostrar();
        System.out.println(" mostrando lista circular ");
        listaCircular.mostrar();
        System.out.println(" vaciamos los impares en los pares pero de su final ");
        listaCircular.vaciarFin(listaNormal);
        listaNormal.mostrar();
        reset();
    }
    public static void main(String[] args) {

        Main.p13vaciarIni();
        Main.p14vaciarFin();

    }
}
