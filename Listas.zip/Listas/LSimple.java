package Listas;

public abstract class LSimple {
    protected NodoS p;

    LSimple() {
        p = null;
    }

    public boolean esVacia() {
        return p == null;
    }

    abstract int nElem();

    abstract void adiFin(Object dato);

    abstract void adiPrimero(Object dato);

    // abstract void adiDespuesKnodo(int k,Object da);
    // abstract void adiAntesKnodo(int k,Object da);
    abstract Object eliFin();

    abstract Object eliPrimero();

    // abstract Object eliKesinodo(int k);
    abstract void mostrar();

    abstract boolean buscar(Object ele);//metodo para verificar si, cierto dato esta ubicado en la lista

    //  ---- metodos para adicionar datos en medio de las listas  ----/* */ 
    public void adiNod(int i, Object ele) {//i toma la k-esima posicion, si la lista es de 3 datos, hay 4 espacios, en medio y en los costados
        int lim = this.nElem() + 1;
        if(i==1){ this.adiPrimero(ele);//si la referencia es 1, sera el primero de la lista
        }else if(i==lim){ this.adiFin(ele);//si la referencia es la ultima posicion de la lista, sera el ultimo
        }else if(1 < i && i < lim){
            NodoS u = p,  l = new NodoS();
            l.setDato(ele);
            for(int j = 2; j<i ;j++){//empieza de 2, porque el primer espacio del nodo inicial, es el segundo espacio
                u = u.getSig();
            }
            l.setSig(u.getSig());
            u.setSig(l);
        }else{ System.out.println("no se pudo insertar, "+i+" es una direccion invalida");}
    }

    public void adiRef(Object ref, Object ele) {//ref es el objeto de referencia, donde estara el nuevo elemento
        if(this.buscar(ref)){
            int lim = this.nElem();
            NodoS u = this.p;
            for(int i = 1 ; i<= lim ; i++){
                if(u.getDato().equals(ref)){
                    this.adiNod(i+1, ele);//el nuevo objeto estara despues de la referencia
                    break;
                }else{
                    u = u.getSig();
                }
            }
        }else{  System.out.println("no se pudo insertar, la lista no tiene referencia del objeto : "+ref); }
    }
    //  ---- metodos para eliminar datos en medio de las listas  ---- /* */
    public Object eliNod(int i) {//se eliminara el k-esimo nodo
        Object ele = null;
        int lim = this.nElem();
        if(i==1){ele = this.eliPrimero();// si el nodo a borrar es 1, se elimina el primero
        }else if(i == lim){ele = this.eliFin();// se borra el ultimo nodo, si el argumento apunta a los nElem() de la lista
        }else if(1 < i && i < lim){
            NodoS u = this.p;    //este solo sirve para recuperar los nodos que se desconectaron de x
            NodoS x = u.getSig();//x sera el k-esimo nodo
            for(int j = 2; j < i ; j++){//empieza de 2 porque 'x' ya es el segundo elemento al empezar el recorrido
                u = u.getSig();
                x = x.getSig();
            }
            ele = x.getDato();
            u.setSig( x.getSig() );//aqui se elimina el nodo de la lista.
        }else{System.out.println("no se pudo eliminar, "+i+" es una direccion invalida");}
        return ele;
    }

    public Object eliRef(Object ref) {//eliminara el primer nodo que contenga este objeto
        Object ele = null;
        if(this.buscar(ref)){
            int lim = this.nElem();
            NodoS u = this.p;
            for(int j = 1 ; j<=lim ; j++){
                if(u.getDato().equals(ref)){
                    ele = this.eliNod(j);//aqui se elimina el dato referenciado
                    break;
                }else{
                    u = u.getSig();
                }
            }
        }else{ System.out.println("no se pudo eliminar, la lista no tiene referencia del objeto : "+ref); }
        return ele;
    }
    //  ---- metodos de vaciar datos de una lista a otra  ---- /* */
    public void vaciarFin(LSimple l){//vacia los datos de la lista a otra, y las ubica al final de la lista argumentada
        if(this.esVacia()){ System.out.println("la lista ya esta vacia");
        }else{                          //lista x = a, b, c
            while(!this.esVacia()){      //lista y = 1, 2, 3
                l.adiFin(this.eliPrimero());//x.vaciarFin(y) --> y = 1, 2, 3, a, b, c  |
            }
        }
    }

    public void vaciarIni(LSimple l){//vacia los datos de la lista a otra, y las ubica al inicio de la lista argumentada
        if(this.esVacia()){ System.out.println("la lista ya esta vacia");
        }else{                          //lista x = a, b, c
            while(!this.esVacia()){      //lista y = 1, 2, 3
                l.adiPrimero(this.eliFin());//x.vaciarIni(y) --> y = a, b, c, 1, 2, 3  |
            }
        }
    }
}