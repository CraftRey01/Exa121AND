import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        LSNormal listaOriginal = new LSNormal();

        // Solicitar al usuario que ingrese los números
        System.out.print("Ingrese números separados por comas (0 para terminar): ");
        String input = leerDesdeTeclado();
        
        // Procesar la entrada
        String[] numeros = input.split(",");
        for (String numeroStr : numeros) {
            int num = Integer.parseInt(numeroStr.trim());
            if (num == 0) {
                break;
            }
            listaOriginal.adiFin(num);
        }

        // Organizar la lista original combinando pares e impares
        organizar(listaOriginal);

        // Mostrar la lista original organizada
        listaOriginal.mostrar();
    }

    static void organizar(LSNormal lista) {
        // Crear dos listas auxiliares para almacenar pares e impares
        LSNormal par = new LSNormal();
        LSNormal imp = new LSNormal();

        // Separar la lista original en listas de pares e impares
        NodoS a = lista.getCabecera();
        while (a != null) {
            if (a.getDato() % 2 == 0) {
                par.adiFin(a.getDato());
            } else {
                imp.adiFin(a.getDato());
            }
            a = a.getSig();
        }

        // Organizar la lista original combinando pares e impares
        lista.setCabecera(null); // Vaciar la lista original

        NodoS apar = par.getCabecera();
        NodoS aimp = imp.getCabecera();

        while (apar != null || aimp != null) {
            if (aimp != null) {
                lista.adiFin(aimp.getDato());
                aimp = aimp.getSig();
            }

            if (apar != null) {
                lista.adiFin(apar.getDato());
                apar = apar.getSig();
            }
        }
    }

    static String leerDesdeTeclado() {
        Scanner scanner = new Scanner(System.in);
        return scanner.nextLine();
    }

    // Resto del código (clases NodoS y LSNormal) sin cambios

    public static class NodoS {
        private int dato;
        private NodoS sig;

        public NodoS(int dato) {
            this.dato = dato;
            this.sig = null;
        }

        public int getDato() {
            return dato;
        }

        public void setDato(int dato) {
            this.dato = dato;
        }

        public NodoS getSig() {
            return sig;
        }

        public void setSig(NodoS sig) {
            this.sig = sig;
        }
    }

    public static class LSNormal {
        private NodoS p;

        public LSNormal() {
            this.p = null;
        }

        public boolean esVacia() {
            return (this.p == null);
        }

        public NodoS getCabecera() {
            return p;
        }

        public void setCabecera(NodoS q) {
            this.p = q;
        }

        public void adiFin(int dato) {
            NodoS x, u;
            x = new NodoS(dato);
            if (esVacia())
                p = x;
            else {
                u = p;
                while (u.getSig() != null)
                    u = u.getSig();
                u.setSig(x);
            }
        }

        public void mostrar() {
            NodoS y = p;
            while (y != null) {
                System.out.print("\t" + y.getDato());
                y = y.getSig();
            }
            System.out.println();
        }
    }
}
